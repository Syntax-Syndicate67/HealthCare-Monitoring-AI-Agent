import sqlite3, pandas as pd, datetime, os
import gradio as gr

DB_PATH = "health_data.db"
conn = sqlite3.connect(DB_PATH, check_same_thread=False)
cur = conn.cursor()

# Create tables
cur.execute('''
CREATE TABLE IF NOT EXISTS medications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    time TEXT NOT NULL,
    taken INTEGER DEFAULT 0
)
''')
cur.execute('''
CREATE TABLE IF NOT EXISTS health_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    steps INTEGER DEFAULT 0,
    calories INTEGER DEFAULT 0
)
''')
conn.commit()

def add_med(name, time_str):
    if not name or not time_str:
        return "Please provide medicine name and time (HH:MM)."
    try:
        hh, mm = map(int, str(time_str).split(":")[:2])
        tnorm = f"{hh:02d}:{mm:02d}"
    except Exception:
        return "Time must be in HH:MM format (e.g. 08:30)."
    cur.execute("INSERT INTO medications (name, time) VALUES (?,?)", (name.strip(), tnorm))
    conn.commit()
    return f"Added '{name.strip()}' at {tnorm}."

def view_meds():
    return pd.read_sql("SELECT * FROM medications ORDER BY time", conn)

def mark_taken(med_id):
    try:
        cur.execute("UPDATE medications SET taken=1 WHERE id=?", (int(med_id),))
        conn.commit()
        return f"Marked medication id {med_id} as taken."
    except Exception as e:
        return f"Error: {e}"

def clear_taken():
    cur.execute("UPDATE medications SET taken=0")
    conn.commit()
    return "Reset 'taken' status for all medications."

def add_metrics(date_str, steps, calories):
    try:
        datetime.datetime.strptime(date_str, "%Y-%m-%d")
    except Exception:
        return "Date must be YYYY-MM-DD."
    cur.execute("INSERT INTO health_metrics (date, steps, calories) VALUES (?,?,?)",
                (date_str, int(steps or 0), int(calories or 0)))
    conn.commit()
    return f"Saved metrics for {date_str}."

def view_metrics():
    return pd.read_sql("SELECT * FROM health_metrics ORDER BY date DESC", conn)

def check_reminders_now():
    now = datetime.datetime.now()
    df = pd.read_sql("SELECT * FROM medications WHERE taken=0", conn)
    if df.empty:
        return "No pending medication reminders."
    soon = []
    for _, row in df.iterrows():
        try:
            med_time = datetime.datetime.strptime(row['time'], "%H:%M")
            med_dt = now.replace(hour=med_time.hour, minute=med_time.minute, second=0, microsecond=0)
            diff = int((med_dt - now).total_seconds() / 60)
            if abs(diff) <= 15:
                soon.append(f"{row['name']} at {row['time']} (id={row['id']}) — {diff} min {'late' if diff<0 else 'away'}")
        except Exception:
            continue
    if not soon:
        return "No reminders within ±15 minutes from now."
    return "\n".join(soon)

with gr.Blocks() as demo:
    gr.Markdown("## 🩺 Healthcare Monitoring AI Agent — Week 1 (Colab + Gradio)")
    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("### Add Medication")
            m_name = gr.Textbox(label="Medicine name", placeholder="e.g. Paracetamol")
            m_time = gr.Textbox(label="Time (HH:MM)", placeholder="08:30")
            add_btn = gr.Button("Add Reminder")
            add_status = gr.Textbox(label="Status", interactive=False)
            add_btn.click(add_med, inputs=[m_name, m_time], outputs=add_status)

            gr.Markdown("### Medication Actions")
            view_btn = gr.Button("View Schedule")
            meds_table = gr.Dataframe(headers=["id","name","time","taken"])
            view_btn.click(lambda: pd.read_sql("SELECT * FROM medications ORDER BY time", conn), outputs=meds_table)

            med_id = gr.Number(label="Medication id to mark taken")
            mark_btn = gr.Button("Mark Taken")
            mark_out = gr.Textbox(label="Mark status", interactive=False)
            mark_btn.click(mark_taken, inputs=med_id, outputs=mark_out)

            reset_btn = gr.Button("Reset 'taken' flags")
            reset_out = gr.Textbox()
            reset_btn.click(clear_taken, outputs=reset_out)

        with gr.Column(scale=1):
            gr.Markdown("### Health Metrics")
            date_in = gr.Textbox(label="Date (YYYY-MM-DD)", value=datetime.date.today().isoformat())
            steps_in = gr.Number(label="Steps", value=0)
            cal_in = gr.Number(label="Calories", value=0)
            save_metrics = gr.Button("Save Metrics")
            metrics_status = gr.Textbox()
            save_metrics.click(add_metrics, inputs=[date_in, steps_in, cal_in], outputs=metrics_status)

            view_metrics_btn = gr.Button("View Metrics")
            metrics_table = gr.Dataframe()
            view_metrics_btn.click(lambda: pd.read_sql("SELECT * FROM health_metrics ORDER BY date DESC", conn), outputs=metrics_table)

            gr.Markdown("### Reminders")
            check_btn = gr.Button("Check Reminders (±15 min)")
            reminders_out = gr.Textbox(label="Upcoming reminders", interactive=False)
            check_btn.click(check_reminders_now, outputs=reminders_out)

    gr.Markdown("_DB file `health_data.db` is saved in the Colab VM. Download it if you want to preserve data._")

demo.launch(share=False)
